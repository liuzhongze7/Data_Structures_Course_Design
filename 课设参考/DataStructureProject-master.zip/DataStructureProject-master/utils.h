#ifndef UITLS_H
#define UITLS_H

#include <QString>

bool checkPlate(QString plate);
#endif // UITLS_H
