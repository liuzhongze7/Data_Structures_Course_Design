package teacher.mapper;

public interface StuTaskFilesMapper {

}
