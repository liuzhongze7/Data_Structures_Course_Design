package teacher.action;

import com.opensymphony.xwork2.ActionSupport;

public class TeaCourseTestAction extends ActionSupport {

    public String toAddTest() {
        return SUCCESS;
    }
}
