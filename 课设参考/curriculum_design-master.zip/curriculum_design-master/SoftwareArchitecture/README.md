## server

Linux环境下安装 [libevent](https://libevent.org/)

```bash
cd linux server
make
./server
```

## client

- 安装QT后编译客户端项目