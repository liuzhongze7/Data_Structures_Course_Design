#include"MiniSpanTree_PRIM.h"

int main() {
	MGraph G;
	CreateUDN(G);
	MiniSpanTree_PRIM(G,1);
}
