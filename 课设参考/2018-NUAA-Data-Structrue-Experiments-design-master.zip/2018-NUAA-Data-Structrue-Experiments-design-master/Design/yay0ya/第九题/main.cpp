#include"Graph.h"
int main() {
	MGraph G;
	CreateUDG(G);
}
